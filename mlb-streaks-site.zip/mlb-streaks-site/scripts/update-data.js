const fs = require('fs');
const cheerio = require('cheerio');

const season = new Date().getFullYear();
const bmUrl = 'https://www.baseballmusings.com/cgi-bin/CurStreak.py';
const mlbBase = 'https://statsapi.mlb.com/api/v1';

async function getJson(url){ const r = await fetch(url); if(!r.ok) throw new Error(`${r.status} ${url}`); return r.json(); }
async function getText(url){ const r = await fetch(url); if(!r.ok) throw new Error(`${r.status} ${url}`); return r.text(); }

async function getHitStreaks(){
  const html = await getText(bmUrl);
  const $ = cheerio.load(html);
  const rows = [];
  $('tr').each((_, tr) => {
    const cells = $(tr).find('td').map((_, td) => $(td).text().trim()).get();
    if(cells.length >= 13 && cells[0] !== 'Player') {
      rows.push({
        player: cells[0], games:+cells[1], atBats:+cells[2], runs:+cells[3], hits:+cells[4],
        hr:+cells[5], rbi:+cells[6], bb:+cells[7], k:+cells[8], ba:cells[9], oba:cells[10], slug:cells[11], lastGameDate:cells[12]
      });
    }
  });
  return rows.sort((a,b)=>b.games-a.games);
}

async function getPlayersWithHR(){
  const url = `${mlbBase}/stats?stats=season&group=hitting&playerPool=ALL&season=${season}&limit=5000`;
  const data = await getJson(url);
  return (data.stats?.[0]?.splits || [])
    .filter(s => Number(s.stat?.homeRuns || 0) > 0)
    .map(s => ({ id:s.player.id, name:s.player.fullName }));
}

async function getHRStreakForPlayer(p){
  const url = `${mlbBase}/people/${p.id}/stats?stats=gameLog&group=hitting&season=${season}`;
  const data = await getJson(url);
  const games = (data.stats?.[0]?.splits || []).sort((a,b)=> new Date(b.date)-new Date(a.date));
  let streak = 0, hrs = 0, lastGameDate = '';
  for(const g of games){
    const hr = Number(g.stat?.homeRuns || 0);
    if(hr > 0){ streak++; hrs += hr; if(!lastGameDate) lastGameDate = g.date; }
    else break;
  }
  return streak > 0 ? { player:p.name, games:streak, hr:hrs, lastGameDate } : null;
}

async function runLimited(items, limit, fn){
  const out = []; let i = 0;
  async function worker(){
    while(i < items.length){
      const item = items[i++];
      try { const v = await fn(item); if(v) out.push(v); } catch(e){ console.log('skip', item.name, e.message); }
    }
  }
  await Promise.all(Array.from({length:limit}, worker));
  return out;
}

(async()=>{
  const hits = await getHitStreaks();
  const players = await getPlayersWithHR();
  const hr = (await runLimited(players, 8, getHRStreakForPlayer)).sort((a,b)=>b.games-a.games || b.hr-a.hr);
  fs.writeFileSync('data/streaks.json', JSON.stringify({ updated:new Date().toLocaleString(), source:bmUrl, hits, hr }, null, 2));
  console.log(`Saved ${hits.length} hit streaks and ${hr.length} HR streaks`);
})();
